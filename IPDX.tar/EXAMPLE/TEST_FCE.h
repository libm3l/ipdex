
#ifndef __TESTFCE_H_
#define __TESTFCE_H_

void TEST_FCE(int, thread_args_t *);

#endif
