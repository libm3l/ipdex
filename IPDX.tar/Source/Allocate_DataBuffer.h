
#ifndef  __ALLOCATE_DATABUFFER_H__
#define  __ALLOCATE_DATABUFFER_H__

node_t *Allocate_DataBuffer(node_t *);

#endif
