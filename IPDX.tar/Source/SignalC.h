
#ifndef  __SIGNALC_H__
#define __SIGNALC_H__

extern void catch_int(lmint_t);
extern void catch_usr(lmint_t);

#endif
