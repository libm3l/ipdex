
#ifndef  __DATA_THREAD_H__
#define  __DATA_THREAD_H__

data_thread_str_t *Data_Thread(node_t *);

#endif
