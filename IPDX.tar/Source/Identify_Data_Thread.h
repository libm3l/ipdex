
#ifndef  __IDENTIFY_DATA_THREAD_H__
#define  __IDENTIFY_DATA_THREAD_H__

lmint_t Identify_Data_Thread(data_thread_str_t **);

#endif
