
#ifndef   __START_SR_HUB_THREADS_H__
#define  __START_SR_HUB_THREADS_H__

SR_hub_thread_str_t *Start_SR_HubThread(SR_thread_str_t *, data_thread_args_t *, lmsize_t *, lmsize_t  *, lmint_t *, sem_t);

#endif
