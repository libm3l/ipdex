
#ifndef  __IO_FUNCTIONS_H__
#define  __IO_FUNCTIONS_H__

extern lmint_t Send_Data(node_t *, const lmchar_t *hostname, lmint_t portnumber, lmchar_t *, ...);

#endif
