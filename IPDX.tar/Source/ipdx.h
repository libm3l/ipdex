

#ifndef __IPDX_HEADER_H__
#define __IPDX_HEADER_H__

#define EOFCY 1EOFbuff
#define EOFCN 1EOFbuff

#endif
