
#ifndef  __CHECK_REQUEST__H
#define  __CHECK_REQUEST__H

lmint_t Check_Request(node_t *, lmchar_t *, lmchar_t *, lmchar_t *);
find_t *find_Queued_Reqst(node_t *);

#endif
