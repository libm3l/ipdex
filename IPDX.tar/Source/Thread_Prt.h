
#ifndef  __THREAD_PRT_H__
#define  __THREAD_PRT_H__

void *Data_Threads(void *);

#endif
