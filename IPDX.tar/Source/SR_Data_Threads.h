
#ifndef  __ST_DATA_THREADS_H__
#define  __ST_DATA_THREADS_H__

extern void *SR_Data_Threads(void *);
extern lmint_t S_EOFC(lmint_t, lmint_t);

#endif
