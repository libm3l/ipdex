
#ifndef   __START_SR_THREADS_H__
#define  __START_SR_THREADS_H__

SR_thread_str_t *Start_SR_Threads(lmint_t);

#endif
